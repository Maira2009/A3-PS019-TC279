# DATAQUEST

DATAQUEST is a local web prototype for AIORI-3 PS-019. It discovers potential personal-data fields in CSV and SQLite sources, traces equal normalized values across source locations, maps declared purpose and retention evidence, records human review, and calculates reproducible metrics from manual labels.

The application uses deterministic rules. It does not call an LLM, upload scanned data, use telemetry, or make legal-compliance claims.

## What works

- Create, open, and delete local workspaces.
- Upload multiple CSV and SQLite files with type, size, signature, and path validation.
- Profile fields with inferred types, counts, warnings, and masked samples.
- Configure five editable prototype classes: PHONE, EMAIL, PERSON_NAME, ADDRESS, and PERSONAL_ID.
- Detect field candidates from aliases, value patterns, type signals, weights, and thresholds.
- Trace conservative scan-local overlap groups without storing raw candidate values.
- Resolve purpose and retention declarations by scope precedence.
- Accept, reject, or defer findings with append-only review history.
- Evaluate predictions against the included manual labels with TP, FP, FN, TN, precision, recall, and support.
- Export masked inventory, footprints, evidence gaps, review history, metrics, and Markdown/HTML reports.
- Use a complete synthetic demo containing two CSV files and one SQLite database.

The presentation states that the prototype has five data classes but does not name them. The five classes above are a **prototype implementation decision** and are editable in the Rules page.

## Screenshots

No screenshots are committed. Run the application and capture the live Welcome, Overview, Inventory, and Footprint pages if screenshots are needed for submission.

## Prerequisites

- Python 3.11 or newer
- Node.js 20 or newer with npm
- A modern browser

## Windows PowerShell setup

Open two PowerShell windows from this project directory.

Backend:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Frontend:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://127.0.0.1:5173`. API documentation is available locally at `http://127.0.0.1:8000/docs`.

## macOS and Linux setup

Backend:

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Frontend:

```bash
cd frontend
npm install
npm run dev
```

Open `http://127.0.0.1:5173`.

## Demo workflow

1. Start both services.
2. Select **Load synthetic demo workspace** on the Welcome page.
3. Open Overview to inspect metrics derived from the completed demo scan.
4. Open Inventory and select `guardian_phone`, `Phone Data Detected`, or `mobile`.
5. Open Footprint to view the masked phone overlap across three sources.
6. Open Metadata to compare purpose-present/retention-missing and purpose-missing/retention-present evidence.
7. Open Review to record decisions and notes.
8. Open Evaluation and run the manual labels.
9. Open Reports to download privacy-safe artifacts.

The synthetic files are in `backend/data/demo/`. All names, email addresses, phone-like values, identifiers, and addresses are fictional examples.

## Uploading your own sources

Create or open a workspace, then use Sources to upload `.csv`, `.db`, `.sqlite`, or `.sqlite3` files. The default limit is 25 MB per file. DATAQUEST copies uploads into `backend/runtime/uploads/` and reads SQLite copies in read-only mode. It never modifies the original file.

The scan page lets you choose registered sources and set row/sample limits. Empty, unreadable, malformed, corrupt, unsupported, or oversized sources produce warnings or safe errors. A failure in one source can produce a partial scan while valid sources continue.

## Rules and metadata

Use Rules to edit enabled state, aliases, regex patterns, evidence weights, thresholds, and notes. Saving creates a versioned snapshot. Invalid regexes and invalid weights are rejected.

Use Metadata to create declarations at workspace, class, source, object, or field scope. The most specific matching declaration wins. Placeholder text such as `TBD` or `unknown` is partial evidence, not present evidence. CSV import/export uses the headers documented in [DATA_DICTIONARY.md](docs/DATA_DICTIONARY.md).

## Tests

Backend:

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
pytest -q
```

Frontend:

```powershell
cd frontend
npm test
npm run build
```

The automated suite covers health/local-only behavior, CORS, field alias controls, regex validation, the full demo API flow, read-only SQLite profiling, metadata gaps, scan-local overlap, append-only reviews, metric arithmetic, privacy-safe exports, formula-injection neutralization, invalid uploads, empty files, and confirmed deletion. See [TEST_PLAN.md](docs/TEST_PLAN.md).

## Reset and deletion

- Use Privacy and Settings to delete the selected workspace after confirmation.
- Workspace deletion removes copied uploads and workspace-owned database records. It never deletes the original user files.
- To reset all development state while both servers are stopped, delete the `backend/runtime/` directory.

## Storage and privacy model

- Application database: `backend/runtime/dataquest.sqlite3`
- Copied uploads: `backend/runtime/uploads/`
- Browser state: active workspace and scan IDs in local storage
- API: `127.0.0.1:8000`
- Frontend: `127.0.0.1:5173`

Raw candidate values are processed inside the backend. Results keep masked samples, explanations, metadata state, and source locations. Overlap grouping uses a random in-memory secret for each scan; stored group IDs do not support comparison between scans. Exports exclude raw values and fingerprints. See [PRIVACY.md](docs/PRIVACY.md).

## Troubleshooting

- **Port 8000 or 5173 is in use:** stop the conflicting process. If you change the API port, set `VITE_API_BASE` and include the frontend origin in `DATAQUEST_ALLOWED_ORIGINS`.
- **API unavailable:** confirm `GET http://127.0.0.1:8000/health` returns `status: ok` and that both services use `127.0.0.1`.
- **File rejected:** verify extension, 25 MB limit, and SQLite signature. Rename-only conversions do not create a valid SQLite file.
- **SQLite unreadable or locked:** close other tools that hold an exclusive lock, copy the database, and retry. DATAQUEST waits briefly and then returns an actionable error.
- **Missing Python package:** activate the project virtual environment and rerun `python -m pip install -r requirements.txt`.
- **Missing frontend package:** remove `frontend/node_modules`, then rerun `npm install`.
- **PowerShell activation blocked:** run `.venv\Scripts\python.exe -m pip install -r requirements.txt` and `.venv\Scripts\python.exe -m uvicorn ...` without activation.

## Limitations

- Detection is heuristic and cannot discover all personal data.
- Equal normalized values are potential overlaps, not proof of identity, ownership, sharing authorization, or recency.
- The prototype scans only CSV and SQLite files.
- Name and address value patterns are intentionally conservative and depend heavily on field context.
- Purpose and retention entries record declared evidence; they do not determine legal sufficiency.
- The included labels are small and synthetic. Their metrics do not establish production accuracy.
- Scans run synchronously in this hackathon prototype. They are bounded and report genuine stages, but very large jobs should use a durable worker in a production system.
- The prototype has not undergone a security audit and is not a compliance certification system.

## Project documents

- [Architecture](docs/ARCHITECTURE.md)
- [Data dictionary](docs/DATA_DICTIONARY.md)
- [Privacy model](docs/PRIVACY.md)
- [Demo script](docs/DEMO_SCRIPT.md)
- [Test plan and acceptance coverage](docs/TEST_PLAN.md)
- [Verified test results](docs/TEST_RESULTS.md)
- [Setup guide](docs/SETUP_GUIDE.md)
- [Requirements traceability](docs/REQUIREMENTS_TRACEABILITY.md)
- [Deliverable manifest](MANIFEST.md)

## Acceptance checklist

- [x] Local FastAPI and React/Vite application
- [x] Two CSV and one read-only SQLite demo sources
- [x] Masked profiling and deterministic detection
- [x] Five editable prototype classes
- [x] Three-source potential phone overlap
- [x] Purpose and retention evidence gaps
- [x] Human review with append-only history
- [x] Manual labels and computed metrics
- [x] Masked exports and formula-injection defense
- [x] Automated backend/frontend tests and production build

